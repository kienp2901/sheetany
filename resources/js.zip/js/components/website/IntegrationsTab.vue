<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Integrations</h4>
                <p class="text-muted mb-0">Add third party integrations to your website</p>
            </div>
        </div>

        <div class="row g-4">
            <!-- Google Analytics -->
            <div class="col-md-6">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-warning bg-opacity-20 rounded p-2 me-3">
                                <i class="bi bi-bar-chart text-warning fs-4"></i>
                            </div>
                            <h6 class="mb-0">Google Analytics</h6>
                        </div>
                        <p class="card-text text-muted small">
                            Get traffic insights from your website in your Google Analytics dashboard.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Google Adsense -->
            <div class="col-md-6">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary bg-opacity-20 rounded p-2 me-3">
                                <i class="bi bi-google text-primary fs-4"></i>
                            </div>
                            <h6 class="mb-0">Google Adsense</h6>
                        </div>
                        <p class="card-text text-muted small">
                            Monetize your website with Google AdSense and earn revenue from ads.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Crisp Chat -->
            <div class="col-md-6">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-info bg-opacity-20 rounded p-2 me-3">
                                <i class="bi bi-chat-dots text-info fs-4"></i>
                            </div>
                            <h6 class="mb-0">Crisp Chat</h6>
                        </div>
                        <p class="card-text text-muted small">
                            Engage with your visitors in real-time using Crisp Chat.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Google Tag Manager -->
            <div class="col-md-6">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-success bg-opacity-20 rounded p-2 me-3">
                                <i class="bi bi-tag text-success fs-4"></i>
                            </div>
                            <h6 class="mb-0">Google Tag Manager</h6>
                        </div>
                        <p class="card-text text-muted small">
                            Easily track and manage audience interactions on your website.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Mailchimp -->
            <div class="col-md-6">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-warning bg-opacity-20 rounded p-2 me-3">
                                <i class="bi bi-envelope text-warning fs-4"></i>
                            </div>
                            <div class="flex-fill">
                                <h6 class="mb-0">Mailchimp</h6>
                                <span class="badge bg-secondary small">Coming soon</span>
                            </div>
                        </div>
                        <p class="card-text text-muted small">
                            Grow your audience and manage email marketing campaigns with ease.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Disqus -->
            <div class="col-md-6">
                <div class="card h-100 border-1">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary bg-opacity-20 rounded p-2 me-3">
                                <i class="bi bi-chat-square-text text-primary fs-4"></i>
                            </div>
                            <div class="flex-fill">
                                <h6 class="mb-0">Disqus</h6>
                                <span class="badge bg-secondary small">Coming soon</span>
                            </div>
                        </div>
                        <p class="card-text text-muted small">
                            Enable discussions and user engagement on your blog or website.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>