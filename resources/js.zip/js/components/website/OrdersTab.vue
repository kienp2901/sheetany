<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Orders</h4>
                <p class="text-muted mb-0">Manage your orders</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="bi bi-bag fs-1 text-muted mb-3"></i>
                <h5 class="mb-2">Order Management</h5>
                <p class="text-muted">View and manage your orders</p>
            </div>
        </div>
    </div>
</template>