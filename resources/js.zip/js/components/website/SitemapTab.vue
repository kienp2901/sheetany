<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Sitemap</h4>
                <p class="text-muted mb-0">Manage your sitemap</p>
            </div>
        </div>

        <div class="card border-1">
            <div class="card-body text-center py-5">
                <i class="bi bi-diagram-3 fs-1 text-muted mb-3"></i>
                <h5 class="mb-2">Sitemap Management</h5>
                <p class="text-muted">Configure your website sitemap</p>
            </div>
        </div>
    </div>
</template>