<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Emails</h4>
                <p class="text-muted mb-0">Manage collected emails</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-body text-center py-5">
                <i class="bi bi-envelope fs-1 text-muted mb-3"></i>
                <h5 class="mb-2">Email Management</h5>
                <p class="text-muted">View and manage collected emails</p>
            </div>
        </div>
    </div>
</template>