<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Information sheet</h4>
                <p class="text-muted mb-0">Information sheet mapped from your Google Sheets</p>
            </div>
        </div>

        <div class="card border-1">
            <div class="card-body text-center py-5">
                <i class="bi bi-info-circle fs-1 text-muted mb-3"></i>
                <h5 class="mb-2">Information Sheet</h5>
                <p class="text-muted">Display information sheet data from Google Sheets</p>
            </div>
        </div>
    </div>
</template>